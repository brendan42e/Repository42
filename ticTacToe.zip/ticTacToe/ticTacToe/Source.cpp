// INCLUDES
#pragma warning(disable:4996)
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>

// DEFINES 
#ifndef __TRUE_FALSE__ 
#define __TRUE_FALSE__ 
#define TRUE 1 
#define FALSE 0 
#endif // ROWS and COLS must be between 1 and 9 
#define ROWS 3
#define COLS 3
#define MARKONE 'X' 
#define MARKTWO 'O' 
#define BLANK ' '

// PLAYERMOVE FUNCTION CODES
#define VALID_MOVE 1
#define INVALID_MOVE 0

// VICTORY CODES
#define NOWIN			0
#define MARKONEVICTORY  1
#define MARKTWOVICTORY  2
#define TIE				3
#define ERROR			4
#define EPIC_FAIL		5

// GAME PARAMETER CODES
#define CONSECUTIVE_MARKS_REQUIRED 3

// PROTOTYPES 
void InitializeBoard(char[ROWS][COLS]);
void DisplayBoard(char[ROWS][COLS]);
int PlayerMove(int, int, char[ROWS][COLS], char);
int VictoryCheck(int, char[ROWS][COLS]);
void DisplayVictoryMessage(int);


// MAIN 
int main() {
	char board[ROWS][COLS];
	int counter;
	char symbol;
	int userRow;
	int userColumn;
	
	// LET'S INITIALIZE A BOARD
	InitializeBoard(board); 

	// LET'S SET A COUNTER VARIABLE TO 
	// DETERMINE WHETHER X OR O IS MAKING A MOVE
	counter = 0;
	while (1) {
		// LET'S DISPLAY THE BOARD
		DisplayBoard(board);
		
	

		// MODULUS DETERMINES WHETHER X OR O
		// MAKES THEIR MOVE
		if (counter % 2 == 0) {
			symbol = MARKONE;
		}
		else {
			symbol = MARKTWO;
		}

		
		// LET'S GET USER INPUT
		printf("Select a column: ");
		scanf("%d", &userColumn);
		printf("Select a row: ");
		scanf("%d", &userRow);



		// IF THE MOVE ISN'T VALID, 
		// LET THE USER KNOW
		// OTHERWISE, PLACE THE MOVE
		// ON THE BOARD INCREASING
		// THE COUNTER FOR THE NEXT MOVE
		if (PlayerMove(userColumn, userRow, board, symbol) == INVALID_MOVE) {
			printf("That move is invalid, please try again\nPress any key to continue...");
			_getch();
		}
		else {
			counter++;
		}
	
		DisplayVictoryMessage(VictoryCheck(CONSECUTIVE_MARKS_REQUIRED, board));
		_getch();

		system("cls");
	}
	
	return 0;
}

// INITIALIZES EACH SPACE ON THE BOARD TO BLANK SPACES
void InitializeBoard(char board[ROWS][COLS]) {
	// LOOP THAT INITIALIZES THE SPACES
	for (int i = 0; i < ROWS; i++) {
		for (int j = 0; j < COLS; j++) {
			board[i][j] = { BLANK };
		}
	}
}

// FUNCTION THAT PRINTS THE BOARD
void DisplayBoard(char board[ROWS][COLS]) {
	printf(">> TIC-TAC-TOE <<\n\n");

	printf(" ");
	for (int j = 1; j < COLS + 1; j++) {
		printf("%4d", j);
	}

	printf("\n");
	printf("  ");

	for (int j = 0; j < COLS; j++) {
		printf(" ---");
	}
	printf("\n");

	for (int i = 0; i < ROWS; i++) {
		printf("%d |", i + 1);
		for (int j = 0; j < COLS; j++) {
			printf(" %c |", board[i][j]);
		}
		printf("\n");
		printf("  ");
		for (int j = 0; j < COLS; j++) {
			printf(" ---");
		}
		printf("\n");
	}
	printf("\n");
}


// FUNCTION CALL THAT RETURNS WHETHER
// OR NOT THE MOVE IS VALID
// IF THE MOVE IS VALID,
// FILL THE ARRAY SPACE WITH AN X OR O
// DEPENDING ON MAIN()
int PlayerMove(int col, int row, char board[ROWS][COLS], char symbol) {
	int returnCode;

	if (board[row - 1][col - 1] == BLANK) {
		board[row - 1][col - 1] = symbol;
		returnCode = VALID_MOVE;

	}
	else {
		returnCode = INVALID_MOVE;
	}

	return returnCode;
}

int VictoryCheck(int winRequirement, char board[ROWS][COLS]) { 
	bool winFound = false;


	
	
	bool xWins = true;
	bool yWins = true;
	// LET'S LOOP THROUGH EACH ROW TO DETERMINE
	// IF THERE'S A HORIZONTAL VICTORY
	for (int x = 0; x < ROWS; x++) {

		if (winFound == false) {
			// LET'S SET THE FIRST CHARACTER OF THE
			// HORIZONTAL ROW SO WE CAN COMPARE IT
			// TO THE REST OF THE ELEMENTS BEING CHECKED
			char first = board[x][0];

			// AND NOW WE WILL WILL MOVE THROUGH
			// THE REST OF THE ELEMENTS
			for (int y = 1; y < COLS; y++) {


				if (first == MARKONE) {
					if (first != board[x][y]) {
						xWins = false;
					}
					else {
						yWins = false;
						winFound = true;
					}
				}
				
				if (first == MARKTWO) {
					if (first != board[x][y]) {
						yWins = false;
					}
					else {
						xWins = false;
						winFound = true;
					}
				}
			}
		}
	}


	
	if (xWins == false && yWins == false && winFound == false) {
		return NOWIN;
	}
	else if (xWins == true && winFound == true) {
		return MARKONEVICTORY;
	}
	else if (yWins == true && winFound == true) {
		return MARKTWOVICTORY;
	}
	
}

void DisplayVictoryMessage(int victoryCode) {

	switch (victoryCode) {

	case NOWIN:
		printf("\nThere is still no winner.\n");
		break;

	case MARKONEVICTORY:
		printf("MARKONE has won the game.\n");
		break;

	case MARKTWOVICTORY:
		printf("MARKTWO has won the game\n");
		break;

	case TIE:
		printf("The game is a draw.\n");
		break;

	case ERROR:
		printf("Something bad happened... MARKONE and MARKTWO have both won.\n");
		break;

	case EPIC_FAIL:
		printf("Something bad happened... VictoryCheck() has produced an impossible combination of return code indicators.\n");
		break;

	default:
		printf("DisplayVictoryMessage() was passed an invalid victoryCode.\n");

	}
}



